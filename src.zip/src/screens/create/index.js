import React, { Component } from "react";
import {AppRegistry,Image,View,}  from 'react-native';
import {Container,Header,Title,Toast,Content,Button,Item,Label,Input,Body,Left,Right,Icon,Form,Text,H3} from "native-base";
import sorage from "../util/MySorage";
import style from "../style";
const dismissKeyboard = require('dismissKeyboard');
export default class Create extends Component {
  render() {
    return (
      <Container style={style.container}>
        <Header style={style.bgc}>
          <Left>
            <Button transparent onPress={() => this.props.navigation.goBack()}>
              <Icon name="arrow-back" />
            </Button>
          </Left>
          <Body>
            <Title>Create Account</Title>
          </Body>
          <Right />
        </Header>
        <Content>
          <Form style={{marginTop:50}}>
            <Text style={{textAlign:'center',marginBottom:15}}>
                <Image source={require('../img/logo.jpg')} style={style.imgSize}/>
            </Text>
             <H3 style={{textAlign:'center',marginBottom:45,color:'#666'}}>Create Account</H3>
            <Item style={style.ItemStyle}>
              <Input
              onPress={()=>{
                this.setState({untext:'Useless Multiline Placeholder'})}}
              onChangeText={(text) => {this.userName = text;  }} placeholder="Mobile phone" style={style.input}/>
            </Item>
            <Item style={style.ItemStyle}>
              <Input
              onPress={()=>{
                this.setState({untext:'Useless Multiline Placeholder'})}}
              onChangeText={(text) => {this.userName = text;  }} placeholder="Password" style={style.input} />
            </Item>
            <Button block style={style.btn}  onPress={() =>this.props.navigation.navigate('Vertification')}>
            <Text>Next</Text>
          </Button>
          </Form>
        </Content>
      </Container>
    );
  }
}
AppRegistry.registerComponent('Create', () => Create);
